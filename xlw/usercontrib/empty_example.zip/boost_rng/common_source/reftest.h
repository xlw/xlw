//
//
//                                                                    reftest.h
//

#ifndef REFTEST_H
#define REFTEST_H

#include <xlw/XlfOper.h>

// Experimental feature to distinguish OPER from XLOPER
typedef xlw::XlfOper reftest;

#endif
